<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

// Credits to -=sIN and sevy for teh script 
if ($row['classid']=="0")
echo "Visitor";
if ($row['classid']=="111")
echo "Soldier";
if ($row['classid']=="121")
echo "Knight";
if ($row['classid']=="122")
echo "Champion";
if ($row['classid']=="211")
echo "Muse";
if ($row['classid']=="221")
echo "Mage";
if ($row['classid']=="222")
echo "Cleric";
if($row['classid']=="311")
echo "Hawker";
if($row['classid']=="321")
echo "Raider";
if($row['classid']=="322")
echo "Scout";
if($row['classid']=="411")
echo "Dealer";
if($row['classid']=="421")
echo "Bourgeois";
if($row['classid']=="422")
echo "Artisan";
?>