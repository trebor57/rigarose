<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

?>  

<form action="index.php?op=admin_login" method="post">
  <p align="center"><strong>Administrator Login :: Administrators Only! </strong></p>
  <div align="center">
    <table width="245" border="0" align="center" class="liteoption">
      <tr>
        <td width="64">Username:</td>
        <td width="165"><label>
          <input type="text" name="user" class="liteoption" />
        </label></td>
      </tr>
      <tr>
        <td>Password:</td>
        <td><input type="password" name="pass" class="liteoption" /></td>
      </tr>
    </table>
  </div>
  <p align="center">
    <input name="submit" type="submit" class="liteoption" id="submit" value="Login!" />
  </p>
  </form>
  <p align="center"> <?php
if(isset($_POST['submit'])) {
$U = $_POST['user'];
$P = md5($_POST['pass']);


$result1 = "SELECT * FROM `accounts` WHERE username='$U' and password='$P' and accesslevel >= '300'";
$query = mysql_query($result1);


$count = mysql_num_rows($query);


if($count == 1){

session_register("Admin");

$_SESSION['account'] = $_POST['user']; 
echo('Logged in..... Click <a href=?op=admin><strong>here</strong>');
}
else {
echo "<strong>Account does not exsit!</strong>";
}
}
?>&nbsp;</p>
  