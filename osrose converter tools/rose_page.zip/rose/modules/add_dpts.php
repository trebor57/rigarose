<?php 
if( ($_SERVER['REQUEST_METHOD'] == 'POST') && isset($_POST['sure']) ) {
    if ( isset($_POST['account_name']) && ctype_digit($_POST['donation_points'])) {
        #mysql_query("UPDATE accounts SET donation = '".$_POST['textfield2']."' WHERE username = '".$_POST['textfield1']."'");
        if ( ctype_digit($_POST['account_name'])) {      
            $sql = "UPDATE accounts SET donation = donation + %d WHERE id=%d;";
        } else {
            $sql = "UPDATE accounts SET donation = donation + %d WHERE username='%s';";
        }
        $sql = sprintf($sql, $_POST['donation_points'], $_POST['account_name']);
        $res = @mysql_query($sql);
        if ( $res === false ) {
            echo 'Adding donation points to <strong>'.$_POST['account_name'].'</strong> has failed! Reason: '. mysql_error(). '<br />';
        } elseif ( mysql_affected_rows() == 0 ) {
            echo 'Appearently <strong>'.$_POST['account_name'].'</strong> does not exist. Please check your parameters! <br />';
        } else {
            echo 'Donation points are added to <strong>'.$_POST['account_name'].'</strong>.<br />';
        }
    } else {
        echo 'Please fill in all the fields.';
    }
} else {
    echo 'If you want to add the donation points, then click the box!';
}
?>
<form id="form1" name="form1" method="post" action="?op=add_dpts">
<table width="275" border="0" align="center">
  <tr>
    <td width="98">Account Name or id: </td>
    <td width="167"><label>
      <input type="text" name="account_name">
    </label></td>
  </tr>
  <tr>
    <td width="98"> Donation PT: </td>
    <td width="167"><label>
      <input type="text" name="donation_points">
    </label></td>
  </tr>
  <tr>
    <td>Are you sure? </td>
    <td><label>
      <input name="sure" type="checkbox" id="sure" value="checkbox">
    </label></td>
  </tr>
</table>
 
<p align="center">
  <input name="submit" type="submit" id="submit" />
  <br />
  <br />
</p>
 
</form>
 