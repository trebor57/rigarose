<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<div align="center">
  <form id='form1' name='form1' method='post' action='<?php $_SERVER['PHP_SELF']; ?>'>
    <label>
    <select name='select'>
      <option value='0'>Choose a class</option>
      <option value='111'>Soldier</option>
      <option value='121'>--Knight</option>
      <option value='122'>--Champion</option>
      <option value='211'>Muse</option>
<option value='221'>--Mage</option>
<option value='222'>--Cleric</option>
<option value='311'>Hawker</option>
<option value='321'>--Raider</option>
<option value='322'>--Scout</option>
<option value='411'>Dealer</option>
<option value='421'>--Bourgeois</option>
<option value='422'>--Artisan</option>
<option value='0'>Visitor</option>
    </select>
    </label>
    <p>
      <label>
      <input name='submit' type='submit' id="submit" value='Change' />
      </label>
    </p>
  </form>
</div>
<div align="center"><?php
if(isset($_POST['submit'])) {
$results = mysql_query("SELECT * FROM characters WHERE account_name = '".$_SESSION['account']."' and char_name = '".$_GET['char']."'");
$rows = mysql_fetch_array($results);
if($rows['account_name'] != $_SESSION['account']) {
die('This is not your character!');
}
if($rows['char_name'] != $_GET['char']) {
die('This is not your character!');
}
$result = mysql_query("UPDATE characters SET classid = '".$_POST['select']."' WHERE char_name = '".$_GET['char']."'");
if(!$result) {
echo('<p class="b01">Cannot change class!</p>');
} else {
echo('<p class="b01">Class change successfull!</p>');
}
	}
?></div>
</body>
</html>
