<?php 
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(User_Name)) {
}

if(!session_is_registered(User_Pass)) {
}
?>
<form action="?op=password" method="post">
  <div align="center"><span class="b01">Password Change </span><br />
    <br />
  </div>
  <table width="306" border="0" align="center">
  <tr>
    <td width="130" class="liteoption">New Password: </td>
    <td width="166"><input name="newpass" type="text" class="liteoption" id="newpass" size="15" maxlength="13" /></td>
  </tr>
</table>
<p align="center">
            <input type="submit" class="liteoption" name="submit" value="Change it" />
</p></form>
</p>
<p align="center"><?php
if(isset($_POST['submit'])) {

$mdfive = md5($_POST['newpass']);


$results = mysql_query("UPDATE `accounts` SET password = '".$mdfive."' WHERE username = '".$_SESSION['account']."'");
if(!$results) {
echo('Result: Password could not be changed.');
} else {
echo('Result: Passwords changed successfully!');
}
}
?>
