<?php

/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(Admin)) {
}

?>
<form action="?op=news" method="post">
  <div align="center"><br />
  </div>
  <table width="500" border="0" align="center">
    <tr>
      <td width="132" height="20" class="b01">News ID:</td>
      <td width="196"><label>
        <input name="id" type="text" class="liteoption" id="id" size="10" maxlength="10" />
      </label></td>
    </tr>
    <tr>
      <td height="25" class="b01">Date:</td>
      <td><input name="date" type="text" class="liteoption" id="date" size="15" maxlength="15" /></td>
    </tr>
    <tr>
      <td height="24" class="b01">Title: </td>
      <td><input name="title" type="text" class="liteoption" id="title" size="35" maxlength="35" /></td>
    </tr>
    <tr>
      <td height="24" align="left" valign="top" class="b01">News: </td>
      <td><textarea name="news" cols="50" rows="10" class="liteoption" id="news"></textarea></td>
    </tr>
  </table>
  <p align="center">&nbsp;</p>
  <p align="center">
    <input name="submit" type="submit" class="liteoption" value="Send News" />
  </p>
</form>
<div align="center">
  <?php
if(isset($_POST['submit'])) {
if(!$_POST['id'] || !$_POST['date'] || !$_POST['title'] || !$_POST['news']) {
die('You must fill in all of the feilds!!!<BR>');
}
if(!get_magic_quotes_gpc()) {
$id = addslashes($_POST['id']);
$date = addslashes($_POST['date']);
$title = addslashes($_POST['title']);
$news = addslashes($_POST['news']);
} else {
$id = $_POST['id'];
$date = $_POST['date'];
$title = $_POST['title'];
$news = $_POST['news'];
}

$check = mysql_query("SELECT * FROM icenews WHERE id = '$id'");
$check2 = mysql_num_rows($check);
if($check2 != '0') {
die("id: '".$id."' is in use!");
}

$insert_member = mysql_query("INSERT INTO icenews (id, news_date, news_title, news) VALUES ('$id', '$date', '$title', '$news')");
if($insert_member) {
echo("<p class='b01'>News Updates! <a href=?op=home>Click here</a>");
} else {
echo("<p class='b01'>Failed!</p>");
}}
?>	
</div>