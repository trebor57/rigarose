<?php

/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>
<form action="?op=register" method="post">
  <div align="center"><br />
  </div>
  <table width="338" border="0" align="center">
    <tr>
      <td width="132" height="20" class="b01">Username:</td>
      <td width="196"><label>
        <input name="user" type="text" class="liteoption" id="user" size="15" maxlength="15" />
      </label></td>
    </tr>
    <tr>
      <td height="25" class="b01">Password:</td>
      <td><input name="pass1" type="password" class="liteoption" id="pass1" size="15" maxlength="15" /></td>
    </tr>
    <tr>
      <td height="24" class="b01">Repeat Password: </td>
      <td><input name="pass2" type="password" class="liteoption" id="pass2" size="15" maxlength="15" /></td>
    </tr>
  </table>
  <p align="center">&nbsp;</p>
  <p align="center">
    <input name="submit" type="submit" class="liteoption" value="Register" />
  </p>
</form>
<div align="center">
  <?php
if(isset($_POST['submit'])) {
if(!$_POST['user'] || !$_POST['pass1'] || !$_POST['pass2']) {
die('You must fill in all of the feilds!!!<BR>');
}
if(!get_magic_quotes_gpc()) {
$user = addslashes($_POST['user']);
$pass = md5($_POST['pass1']);
} else {
$user = $_POST['user'];
$pass = md5($_POST['pass1']);
}
$pass2 = md5($_POST['pass2']);
$check = mysql_query("SELECT * FROM accounts WHERE username = '$user'");
$check2 = mysql_num_rows($check);
if($check2 != '0') {
die("Username: '".$user."' is in use!");
}
if($pass != $pass2) {
die('Passwords dont match!');
}

$insert_member = mysql_query("INSERT INTO accounts (username, password, active) VALUES ('$user', '$pass', '1')");
if($insert_member) {
echo("<p class='b01'>Registration Complete! <a href=?op=home>Click here</a>");
} else {
echo("<p class='b01'>Registration Failed!</p>");
}}
?>	
</div>