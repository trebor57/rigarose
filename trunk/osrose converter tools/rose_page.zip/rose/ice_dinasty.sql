/*Data for the table `dynastycms` */

insert  into `dynastycms`(`Admin`,`GM`,`Dev`,`title`,`forums`,`client`,`patch`,`exprate`,`droprate`,`zulyrate`) values ('Rigamrts','Rigamrts, Chonte11e','Rigamrts','Rigamrts World','http://127.0.0.1/phpbb3/','http://127.0.0.1/rose/downloads/RoseOnline243.exe','http://127.0.0.1/rose/downloads/ROSE_Online_Launcher.zip','1','1','1');

/*Table structure for table `icenews` */

DROP TABLE IF EXISTS `icenews`;

CREATE TABLE `icenews` (
  `id` int(100) DEFAULT NULL,
  `news_date` varchar(100) DEFAULT NULL,
  `news_title` varchar(100) DEFAULT NULL,
  `news` varchar(1000) DEFAULT NULL,
  `events_date` varchar(100) DEFAULT NULL,
  `events_title` varchar(100) DEFAULT NULL,
  `events` varchar(1000) DEFAULT NULL,
  `updates_date` varchar(100) DEFAULT NULL,
  `updates_title` varchar(100) DEFAULT NULL,
  `updates` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `icenews` */

insert  into `icenews`(`id`,`news_date`,`news_title`,`news`,`events_date`,`events_title`,`events`,`updates_date`,`updates_title`,`updates`) values (1,'07/12/10','Welcome','Welcome to the server. Have a great time.',NULL,NULL,NULL,NULL,NULL,NULL);