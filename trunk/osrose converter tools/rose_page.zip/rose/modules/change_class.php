<?php 
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(User_Name)) {
}

if(!session_is_registered(User_Pass)) {
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>

<body>
<div align="center"><form id='form1' name='form1' method='post' action='<?php $_SERVER['PHP_SELF']; ?>'>
  <label><br />
  </label>
  <p>
    <label><span class="b01">Click a character!<br /> 
    <br />
    <?php
mysql_connect($dbhost, $dbuser, $dbpasswd);
mysql_select_db($dbname);

$result = mysql_query("SELECT * FROM characters WHERE account_name = '".$_SESSION['account']."' ORDER BY char_name LIMIT 5");

while($row = mysql_fetch_array( $result )) {
echo "<strong><a href=?op=class_change&char=".$row['char_name'].">".$row['char_name']."</a><BR></strong>";
}


?>
    </span><br />
    <br />
    </label>
  </p>
</form></div>
<p align="center">&nbsp;</p>
</body>
</html>
