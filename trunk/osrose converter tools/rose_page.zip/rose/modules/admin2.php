<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<body><center><h1>Administrator Options</h1><Br />
<table width="250" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>	<p><a href="?op=news">Update News Page</a></p>
      <p><a href="?op=event">Update Events Page</a></p>
      <p><a href="?op=update">Update Updates Page</a></p>
      <p><a href="?op=ban">Ban</a></p>
      <p><a href="?op=unban">Unban</a></p>
      <p><a href="?op=edit_char">Change Class</a></p>
      <p><a href="?op=make_gm">Make a GM</a></p>
      <p><a href="?op=reset_level">Reset Char Level</a></p>
      <p><a href="?op=name_change">Change Char Name</a></p>
      <p><a href="?op=clan_change">Change Clan Name</a></p>
      <p><a href="?op=stat_change">Change Char Stats</a></p>
      <p><a href="?op=level_change">Change Char Level</a></p>
      <p><a href="?op=clan_delete">Delete Clan</a></p>
      <p><a href="?op=account_delete">Delete Account</a></p>
      <p><a href="?op=character_delete">Delete Character</a></p>
      <p><a href="?op=add_dpts">Add Donation Points</a></p>
      <p><a href="?op=itemmall_v2">Item Mall</a></p>
      <p><a href="?op=logout">Logout</a></p> </td>
  </tr>
</table></center>
</body>
</html>