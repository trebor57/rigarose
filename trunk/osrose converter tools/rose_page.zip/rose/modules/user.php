<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(User_Name)) {
}

if(!session_is_registered(User_Pass)) {
}
?>
<form action="?op=edit-char" method="post">
 <p align="center" class="b01">Welcome: <?php echo $_SESSION['account']; ?><strong><br />
    <br />
    </strong>
   <br />


  <br />
  <em><br />  
    </em><a href="?op=password">Change Password</a><br />
    <a href="?op=cuser-delete">Delete my character</a><br />
    <a href="?op=delete_acc">Delete my account</a><br />
    <a href="?op=change_class">Change my class </a><br />
    <a href="?op=itemmall_v2">Item Mall</a><br />
    <a href="?op=logout">Logout</a></p>
</form>
�</p></p>
