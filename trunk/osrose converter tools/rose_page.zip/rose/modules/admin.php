<?php 
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(Admin)) {
}
?>
<center>
<form name="form1" method="post" action="?op=admin">
  <p>
    <legend></legend>
  </p>
  <table width="413" border="0"><br>

    <tr>
      <td width="402" height="204"><strong>S</strong>ite Configuration<br>
        <br>
        <table width="390" border="0">
    	<tr>
          <td>- Title </td>
          <td><input name="title" type="text" id="title" value="<?php getConfig('title'); ?>"></td>
        </tr>
        <tr>
          <td>- Forums </td>
          <td><input name="forums" type="text" id="forums" value="<?php getConfig('forums'); ?>"></td>
        </tr>
        <tr>
          <td>- Client </td>
          <td><input name="client" type="text" id="client" value="<?php getConfig('client'); ?>"></td>
        </tr>
        <tr>
          <td>- Patch</td>
          <td><input name="patch" type="text" id="patch" value="<?php getConfig('patch'); ?>"></td>
        </tr>
        <tr>
          <td>- Exp Rate </td>
          <td><input name="exp" type="text" id="exp" value="<?php getConfig('exprate'); ?>"></td>
        </tr>
        <tr>
          <td>- Drop Rate </td>
          <td><input name="drop" type="text" id="drop" value="<?php getConfig('droprate'); ?>" /></td>
        </tr>
        <tr>
          <td>- Zuly Rate </td>
          <td><input name="zuly" type="text" id="zuly" value="<?php getConfig('zulyrate'); ?>" /></td>
        </tr>
      </table>
      </td>
      <td width="10">&nbsp;</td>
    </tr>
  </table>
 <a href="index.php?op=admin2">Admin   Featurettes</a>  <br><br>
    <input type="submit" name="submit" value="Update Config" />
  <p>
    <?php
  if(isset($_POST['submit'])) {
  $update = mysql_query("UPDATE dynastycms SET title = '".$_POST['title']."'");
  $update = mysql_query("UPDATE dynastycms SET forums = '".$_POST['forums']."'");
  $update = mysql_query("UPDATE dynastycms SET client = '".$_POST['client']."'");
  $update = mysql_query("UPDATE dynastycms SET patch = '".$_POST['patch']."'");
  $update = mysql_query("UPDATE dynastycms SET exprate = '".$_POST['exp']."'");
  $update = mysql_query("UPDATE dynastycms SET droprate = '".$_POST['drop']."'");
  $update = mysql_query("UPDATE dynastycms SET zulyrate = '".$_POST['zuly']."'");
  if(!$update) {
  echo 'Updating the configuration has failed.';
  } else {
  echo '<strong>Configuration Updated</strong>';
  }}
  ?>
    <br>
  </p>
</form>
<br>
        <label></label>
    </p>
</form></center>
<a href="?op=add_dpts">Add Donation Points</a>