<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>
<center><small><a href="index.php?op=clan_ranking">-Clan Ranking-</a><br /></small><h3> Top 50 Players</h3>
<?PHP
$sql = "SELECT
                c.level as level,
                c.char_name as char_name,
                c.zuly as zuly,
                c.classid as classid
                FROM
                characters as c
              LEFT JOIN
                accounts as a
              ON
                (c.account_name = a.username)
              WHERE
                a.accesslevel < 150
              ORDER BY
                c.level
              DESC
              LIMIT 0,50
              ";
$result = @mysql_query($sql) or die(mysql_error());


echo "<table border='0'>";
echo "<tr><th width=1>Level </th> <th width=40%>Character</th> <th width=30%>Zuly</th> <th width=15%>Job</th> </tr>";

while($row = mysql_fetch_array( $result )) {
	echo "<tr><td bgcolor=''>"; 
	echo $row['level'];
	echo "</td><td bgcolor=''>"; 
	echo $row['char_name'];
	echo "</td><td bgcolor=''>"; 
	echo $row['zuly'];
echo "</td><td bgcolor=''>";
	include ('functions/class.php');
	echo "</td></tr>"; 
} 
				echo "</table>";				
	?></center>