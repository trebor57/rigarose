<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>
<table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right"><A href="index.php?op=home">News</A>|<A href="index.php?op=events">Events</A>|<A href="index.php?op=updates">Updates</A></td>
  </tr>
  <tr>
    <td><?PHP
$sql = "SELECT id, news_title, news_date, news from icenews ORDER BY id DESC LIMIT 0,5";
$result = @mysql_query($sql) or die(mysql_error());


echo "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";

while($row = mysql_fetch_array( $result )) {
	echo "<tr><td bgcolor=''>"; 
	echo $row['news_title'];
	echo "</td><td bgcolor=''>"; 
	echo $row['news_date'];
	echo "</td></tr><tr><td bgcolor=''>"; 
	echo $row['news'];
	echo "<p>";
echo "</td>";
	echo "</tr>"; 
} 
				echo "</table>";				
	?></td>
  </tr>
</table></center>