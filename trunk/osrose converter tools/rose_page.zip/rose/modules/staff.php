<style type="text/css">
<!--
.header {
	text-align: center;
	font-size: large;
}
.t1 {
	font-weight: bold;
}
-->
</style>
<center><h1>The Staff</h1></center>
<table width="238" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="84" height="19" align="left" valign="top" class="t1">Admins</td>
    <td width="154"><?php admins() ?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="t1">GMs</td>
    <td><?php gms() ?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="t1">Devs</td>
    <td><?php devs() ?></td>
  </tr>
</table>
<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>