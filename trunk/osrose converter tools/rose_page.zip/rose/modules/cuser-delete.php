<?php 
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(User_Name)) {
}

if(!session_is_registered(User_Pass)) {
}
?>
<form action="?op=cuser-delete" method="post">
  <div align="center" class="b01">Click on the character you want to delete. <br />
    <br />
    <p class="b01"><?php
mysql_connect($dbhost, $dbuser, $dbpasswd);
mysql_select_db($dbname);

$result = mysql_query("SELECT * FROM characters WHERE account_name = '".$_SESSION['account']."' ORDER BY char_name LIMIT 5");

while($row = mysql_fetch_array( $result )) {
echo "<strong><a href=?op=cuser-delete&char=".$row['char_name'].">".$row['char_name']."</a><BR></strong>";
}


?></p>
  </div>
  <p align="center">&nbsp;</p></form>
<p align="center"><?php
if(isset($_GET['char'])) {
$results = mysql_query("SELECT * FROM characters WHERE account_name = '".$_SESSION['account']."' and char_name = '".$_GET['char']."'");
$rows = mysql_fetch_array($results);
if($rows['account_name'] != $_SESSION['account']) {
die('This is not your character!');
}

#if($row['char_name'] != $_GET['char']) {
#die('This is not your character!');
#}
$result = mysql_query("DELETE FROM characters WHERE char_name = '".$_GET['char']."'");
if(!$result) {
echo('Cannot delete "'.$_GET['char'].'" at the moment.');
} else {
echo("Character: '".$_GET['char']."' deleted!");
}
	}
?>&nbsp;</p>
