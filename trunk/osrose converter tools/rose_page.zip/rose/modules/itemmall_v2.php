<style type="text/css">
/*
.type_11 {
	background:#99CCFF;
}
.type_1 {
	background:#CCFF99;
}
.type_13 {
	background:#FFFF99;
}
.type_6 {
	background:#ff8c9e;
}
.type_2, .type_3, .type_4, .type_5, .type_7, .type_8, .type_9,  {
	background:##66CC00;
}
*/
.error_block {
	color: #FF0000;
}
.info_block {
	color: #FF8000;
}
.ok_block {
	color: #008000;
}
</style>
<script language="JavaScript" type="text/javascript">
	<!--
	function conf_purchase( item, quantity, price) {
	  if (window.confirm("Are you sure you want to purchase "+quantity+" "+item+" for "+price+"? This action can not be rolled back!") ) {
	    //window.location.href = to;
		return true;
	  } else {
		return false;
	  }
	}
</script>
<?php
session_start();

################################################
# Script by Rifke for the osrose compunity
# date: 22 Januari 2009
################################################

########### Account information ##################

include('class.table.inc.php');

$item_mall = new itemmallv2();
// Configuring some data
$item_mall->setlog(true); // enable/disable to create an information stream of who bought what
$item_mall->setaccount_id( ( isset($_SESSION['user_account_id']) ) ? $_SESSION['user_account_id'] : -1 ); // set the users account ID
$item_mall->setalevel(100); // set the users access level


// A tiny login screen!
if ( ($_SERVER['REQUEST_METHOD'] == 'POST') ) {
	$sql = "SELECT id FROM accounts WHERE username = '%s' AND password = '%s';";
	$sql = sprintf($sql, mysql_real_escape_string($_POST['user_name']), md5($_POST['password']));
	$res = @mysql_query($sql);
	if ( $res === false ) {
		echo '<p class="error_block">Problem with loggin in</p>';
	} elseif ( mysql_num_rows($res) == 0 ) {
		echo '<p class="error_block">Invalid combination username/password</p>';
	} else {
		echo '<p class="ok_block">Valid login</p>';
		$_SESSION['user_account_id'] = mysql_result($res, 0);
	}
}
if ( isset($_SESSION['user_account_id']) ) {
	#echo 'Welcome: ' . $_SESSION['user_account_id'] . '<br />';
} else {	
	echo '
	<form action="" method="post">
		User name: <input type="text" name="user_name" id="user_name">
		Password: <input type="password" name="password" id="password">
		<input type="submit" name="login" id="login" value="login">
	</form>
	';
}



// variables
$i_cid = ( isset($_GET['i_cid']) && is_numeric($_GET['i_cid']) ) ? $_GET['i_cid'] : 0;
$i_par = ( isset($_GET['i_par']) && is_numeric($_GET['i_par']) ) ? $_GET['i_par'] : -1;
$i_pur = ( isset($_GET['i_pur']) && is_numeric($_GET['i_pur']) ) ? $_GET['i_pur'] : 0;

// make a breadcrum
$item_mall->breadcrum($i_par,$i_cid);

// add item to cart
if ( isset($_GET['i_pur']) && $i_pur > 0 ) {
	$item_mall->addItemToCar($i_pur);
}

if ( isset($_GET['i_cid']) && $i_cid > 0 ) {

	$item_mall->getCategory($i_cid);
	
} else {
	$item_mall->getCategory();
}


class itemmallv2
{
	private $log = false;
	private $alevel = 300;
	private $table_prefs = NULL;
	private $breadcrum = array();
	private $account_id;
	function __construct() {
		$this->table_prefs = array(	'cellspacing' => 0,
									'cellpading' => 2,
									'width'=> '100%',
									'border' => 0,
									'style'=> "td,th { font-family: Tahoma, Verdana, Geneva, Arial, Helvetica, sans-serif; font-size: 1.1em; }"
									);
	}
	// Getters
	function getlog() {
		return $this->log;
	}
	function getalevel() {
		return $this->alevel();
	}
	function gettable_prefs() {
		return $this->table_prefs;
	}
	function getaccount_id(){
		return $this->account_id();
	}
	// Setters
	function setlog($a) {
		$this->log = $a;
	}
	function setalevel($a) {
		$this->alevel = $a;
	}
	function settable_prefs($a) {
		$this->table_prefs = $a;
	}
	function setaccount_id($a) {
		if ( is_numeric($a) )
			$this->account_id = $a;
	}
	
	/*
	* @update	04/02/2009
	* @desc	get storage money/donation 
	* @param	string $type , int $amount
	* @return 	boolean
	*/
	function decreaseMoney($type,$amount) {
		if ( $this->account_id == -1 ) {
			echo '<p class="error_block">You are not logged in.</p>';
			return false;
		}
		if ( $type == 'D' ) {
			$sql = "SELECT donation FROM accounts WHERE id=%d;";
		} else {
			$sql = "SELECT zulystorage FROM accounts WHERE id=%d;";
		}
		$sql = sprintf($sql,$this->account_id);
		$res = @mysql_query($sql);
		if ( $res === false ) {
			echo '<p class="error_block">There has been a problem with adding your item.</p>';
			$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
		} elseif ( mysql_fetch_assoc($res) == 0 ) {
			echo 'Your account does not exists.';
		} else {
			$a = mysql_result($res,0);
			if ( ($a-$amount) < 0 )
				echo '<p class="info_block">You have not enough money to purchase this item.</p>';
			else {
				if ( $type == 'D' ) {
					$sql = "UPDATE accounts SET donation=donation-%d WHERE id=%d AND online=0;";
				} else {
					$sql = "UPDATE accounts SET zulystorage=zulystorage-%d WHERE id=%d AND online=0;";
				}
				$sql = sprintf($sql,$amount, $this->account_id);
				$res = @mysql_query($sql);
				if ( $res === false ) {
					echo '<p class="error_block">Please make sure you are logged out the game!</p>';
					$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
				} elseif ( mysql_affected_rows() == 1 ) {
					return true;
				} else {
					echo '<p class="error_block">Could not purchase your item, please make sure you are logged out of the game!</p>';
				}
				return false;
			}
		}
	}
	/*
	* @update 	23/01/2009
	* @desc 	make a breadcrum so the users can easly hit the 'back' button'
	* @param 	int $i_cid
	* @return	void
	*/
	function breadcrum($i_cid) {
		$b = NULL;
		//$b = '<a href="'.$this->getUrl().'&amp;i_par='.$i_par.'">'.$this->getBreadcrumName($i_cid).'</a> &raquo';
		echo $this->getBreadcrums($i_cid);
		$m = count( $this->breadcrum )-1;
		echo '<div><a href="'.$this->getURL(true).'">Main</a> ';
		if ( $m > 0 ) echo ' &raquo; ';
		foreach ( $this->breadcrum as $index => $value )  {
			if ( $m == $index ) {
				echo ' &raquo; ';
			}
			echo '<a href="'.$this->getURL(true).'&amp;i_cid='.$value[0].'&amp;i_par='.$value[1].'">'.$value[2].'</a>';
			
		}
		echo '</div>';
	}

	function getBreadcrums($i) {
		
		$sql = "SELECT ctitle,cparent FROM mall_category WHERE cid=%d;";
		$sql = sprintf($sql,$i);
		$res = @mysql_query($sql);
		if ( $res === false ) {
			$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
		} elseif ( mysql_num_rows($res) == 0 ) {
			
		} else {
			$r = mysql_fetch_assoc($res);
			$this->getBreadcrums($r['cparent']);
			$this->breadcrum[] = array($i,$r['cparent'],$r['ctitle']);
		}
	}
	/*
	* @update 	02/02/2009
	* @desc 	add an item to a user's cart
	* @param 	int $iid
	* @return	void
	*/
	function addItemToCar($iid) {
		// Check if this item already is in the cart else re raise it
		$sql = "SELECT mc.quantity FROM mall_cart as mc WHERE mc.uid = %d, mc.iid = %d;";
		$sql = sprintf($sql,$this->account_id,$iid);
		$res = @mysql_query($sql);
		
	
		// get some item information (if possible offcourse)
		$sql = "SELECT
					fs.quantity,
					fs.payment,
					fs.price,
					fs.ref_able,
					fs.soc_able,
					mi.item_name,
					mi.item_type,
					mi.item_id
				FROM
					mall_forsale AS fs
					Inner Join mall_items AS mi ON mi.iid = fs.iid
				WHERE
					fs.sid = %d;
				";
		$sql = sprintf($sql,$iid);
		$res = @mysql_query($sql);
		if ( $res === false ) {
			$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
		} elseif ( mysql_num_rows($res) == 0 ) {
			echo '<p class="error_block">The given item doesn not exist anymore.</p>';
		} else {
			$r = mysql_fetch_assoc($res);
			$slotnum = $this->getFreeSlot();
			if ( $slotnum == 0 || $slotnum > 160 ) {
				echo '<p class="error_block">You have no free storage slot(s) available.</p>';
			}
			else {
				if ( $this->decreaseMoney($r['payment'],$r['price']) === true ) {
					$sql = "INSERT INTO storage (owner,itemnum,itemtype,refine,slotnum,socketed,count) VALUES (%d,%d,%d,%d,%d,%d,%d);";
					
					$sql = sprintf($sql,$this->account_id,$r['item_id'],$r['item_type'],$this->gradeToServerGrade($r['ref_able']),$slotnum,$r['soc_able'],$r['quantity']);
					$res = @mysql_query($sql);
					if ( $res === false ) {
						echo '<p class="error_block">Adding your item to your shoping cast has failed.</p>';
						$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
						$this->decreaseMoney($r['payment'],-$r['price']); // re-adding the money to the account when failed.
					} elseif ( mysql_affected_rows() == 1 ) {
						echo '<p class="ok_block">'.$r['item_name'] . ' has been added to your storage<p>';
						$sql = "INSERT INTO mall_log (date_purchased,owner,itemname,itemid,itemtype,quantity,price,payment,socket,refine,slot) VALUES
								(NOW(),%d,'%s',%d,%d,%d,%d,'%s',%d,%d,%d);";
						$sql = sprintf($sql,$this->account_id,$r['item_name'],$r['item_id'],$r['item_type'],$r['quantity'],$r['price'],$r['payment'],$r['soc_able'],$r['ref_able'],$slotnum);
						mysql_query($sql);
					} else {
						echo '<p class="error_block">Your item is not added to your storage.</p>';
						$this->decreaseMoney($r['payment'],-$r['price']); // re-adding the money to the account when failed.
					}
				}
			}
		}
	}
	
	/*
	* @update 	04/02/2009
	* @desc		Get a free slot
	* @param 	void
	* @return 	int 
	*/
	function getFreeSlot() {
		$slotnum = 0;
		$sql = "SELECT slotnum FROM storage WHERE owner=%d;";
		$sql = sprintf($sql,$this->account_id);
		$res = mysql_query($sql);
		if ( !($res === false) ) {
			if ( mysql_num_rows($res) > 0 ) {
				while ( $r = mysql_fetch_assoc($res) ) {
					$slots[] = $r['slotnum'];
				}	
			}
		}
		for ( $x = 159; $x >= 1; $x--) {
			if ( !@in_array($x,$slots) ) {
				$slotnum = $x;
				break;
			}
		}
		return $slotnum;
	}
	/*
	* @update 	22/01/2009
	* @desc	show content of a category
	* @param 	int $cid
	* @return 	void
	*/
	function getItems($cid) {
		$sql = "SELECT
					fs.sid,
					fs.price,
					fs.payment,
					fs.price,
					fs.quantity,
					fs.ref_able,
					fs.soc_able,
					i.image,
					i.item_type,
					i.item_id,
					i.item_name,
					i.item_desc
				FROM
					mall_forsale AS fs
					Inner Join mall_items AS i ON i.iid = fs.iid
				WHERE
					fs.cid = %d
				;
				";
		$sql = sprintf($sql,$cid);
		$res = @mysql_query($sql);
		if ( $res === false ) {
			$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
		} elseif ( mysql_num_rows($res) == 0 ) {
			echo '<p class="error_block">Sorry there are no items available for the selected category.</p>';
		} else {
			// maken van table
			$tbl_cat = new table($this->table_prefs);
			$tbl_cat->table_header( array("Item name", "Quantity", "Socket", "Refine", "Payment", "Price", NULL) );
			while ( $r = mysql_fetch_assoc($res) ) {
				// Keep the header layout in mind or your table will be screwed up... I could built in a check for that but that would just make it havier :) 
				if ( $r['price'] > 0 ) {
					$params = "'".htmlentities($r['item_name'])."', '".htmlentities($r['quantity'])."', '".htmlentities(number_format($r['price']).' '.$r['payment'])."'";
					
					$values = array($r['item_name']. ' <span style="font-size: 0.8em;">('.$r['item_desc']. '</span>)',
									$r['quantity'], 
									( $r['soc_able'] == 1 ) ? 'Y' : 'N', 
									($r['ref_able'] > 0 ) ? 'Grade '.$r['ref_able'] : 'N',
									number_format($r['price']).$r['payment'],
									 '<a href="'.$this->getURL().'&amp;i_pur='.$r['sid'].'" onClick="return conf_purchase('.$params.');">Purchase</a>'
									);
					$tbl_cat->add_values($values, array('valign' => 'top', 'class' => 'type_'.$r['item_id']) );
				}
			}
			$tbl_cat->printTable();
		}
	}
	
	/*
	* @update 	22/01/2009
	* @desc	Getting categories and sub categories.
	* @param 	int $cid
	* @return 	void
	*/
	function getCategory($cid = -1) {
		if ( !is_numeric($cid) ) {
			echo '<p class="error_block">Your (sub)category id is invalid.</p>';
		} else {
			$sql = "SELECT
						c.cid,
						c.ctitle,
						c.cdesc,
						c.cparent
					FROM
						mall_category as c
					WHERE
						c.cparent = %d AND 
						c.cminlevel <= %d AND 
						c.chidden = 0;
					";
			$sql = sprintf($sql,$cid,$this->alevel);
			$res = @mysql_query($sql); // error subpression
			if ( $res === false ) {
				$this->dbError('Database error, ' .mysql_error(). ' in ' . nl2br($sql) .' <br />');
			} elseif ( mysql_num_rows($res) == 0 ) {
				if ( isset($_GET['i_par']) && $_GET['i_par'] < 0 )
					echo '<p class="error_block">Sorry there are no categories available for the selected category.</p>';
				else
					$this->getItems($cid);
			} else {
				$tbl_cat = new table($this->table_prefs);
				$tbl_cat->table_header( array("Category name", "Sub Categories", "Options") );
					while ( $r = mysql_fetch_assoc($res) ) {
						// Keep the header layout in mind or your table will be screwed up... I could built in a check for that but that would just make it havier :) 
						$values = array( $r['ctitle']. ' <span style="font-size: 0.8em;">('.$r['cdesc']. '</span>)',
										 $this->deep_out($r['cid']),
										 '<a href="'.$this->getURL().'&amp;i_cid='.$r['cid'].'&amp;i_par='.$r['cparent'].'">View</a>'
										);
						$tbl_cat->add_values($values, array('valign' => 'top') );
					}
				$tbl_cat->printTable();
			}
		}
	}
	/*
	* @update 	22/01/2009
	* @desc	Deep out a category
	* @param 	int $cid
	* @return 	string $c
	*/
	function deep_out($cid) {
		$c = Null;
		$sql = "SELECT
					c.cid,
					c.ctitle,
					c.cparent
				FROM
					mall_category as c
				WHERE
					c.cparent = %d AND 
					c.cminlevel <= %d AND 
					c.chidden = 0;
				";
		$sql = sprintf($sql,$cid,$this->alevel);
		$res = @mysql_query($sql); // error subpression
		if ( $res === false ) {	
			// ah shame, but no hard feelings acutaly
		} elseif ( mysql_num_rows($res) == 0 ) {
			// already set
			$c = 'None available';
		} else {
			while ( $r = mysql_fetch_assoc($res) ) {
				$c .= '<a href="'.$this->getURL().'&amp;i_cid='.$r['cid'].'&amp;i_par='.$r['cparent'].'">'.$r['ctitle'].'</a> <br />';
			}
		}
		return $c;
	}
	/*
	* @update 	22/01/2009
	* @desc	get a url
	* @param 	none
	* @return 	string $s
	*/
	function getURL($bSkip = false) {
		if ( isset($_GET) ) {
		$i = 0;
		$s = NULL;
		$skip = array('i_cid', 'i_fid','i_pur','i_del', 'i_par');
		$skip_a = array('i_pur');
			foreach ( $_GET AS $index => $waarde ) {
				if ( (in_array($index,$skip) && $bSkip === true ) || in_array($index,$skip_a) ) {
				
				} else {
					$s .= ($i==0) ? '?'.$index.'='.$waarde : '&amp;'.$index.'='.$waarde;
					$i++;
				}
			}
		return $s;
		}
	}
	/*
	* @update 	04/02/2009
	* @desc		Make some kind of log to track when, how many times a user has bought something
	* @param	string itemname, int itemid, int itemtype, int quantity, int price, string payment, int socket, int refine
	* @return	void
	*/
	function addTransactionToLog($itemname,$itemid,$itemtype,$quantity,$price,$payment,$socket,$refine,$slot) {
		if ( $this->log === true ) {
			$sql = "INSERT INTO mall_log (date_purchased,owner,itemname,itemid,itemtype,quantity,price,payment,socket,refine,slot) VALUES
					(NOW(),%d,'%s',%d,%d,%d,%d,'%s',%d,%d,%d);";
			$sql = sprintf($sql,$this->account_id,$itemname,$itemid,$itemtype,$quantity,$price,$payment,$socket,$refine,$slot);
			echo $sql;
			$res = mysql_query($sql);
		}
	}
	/*
	* @update 	04/02/2009
	* @desc	give a grade (0-9) and the function wil convert it in a useable grade to work with for the server (that it will acutaly be refined)
	* @param	int grade
	* @return	int server_grade
	*/
	function gradeToServerGrade($grade) {
		$RefiningGrades = array(0 => 0, 1 => 16, 2 => 32, 3 => 48, 4 => 64, 5 => 80, 6 => 96, 7 => 112, 8 => 128, 9 => 144);
		
		if ( $RefiningGrades[$grade] != null ) {
			$server_grade = $RefiningGrades[$grade];
		}
		else {
			$server_grade = 0;
		}
			return $server_grade;
	}
	function dbError($msg) {
		// GM only
		if ( $this->alevel >= 300 )
			echo '<p clas="error_block">DB ERROR: ' .$msg .'</p>';
	}
}
?>