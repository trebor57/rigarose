<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>

<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gender Statistics</b></p>
<center>Total Male:&nbsp;<?php totalMale() ?><br>
Total Female:&nbsp;<?php totalFemale() ?></center>
<br><br>
<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class Statistics</b></p>
<center>
Total Visitors:&nbsp;<?php totalVisitor() ?><br>
Total Hawkers:&nbsp;<?php totalHawker() ?><br>
Total Soldiers:&nbsp;<?php totalSoldier() ?><br>
Total Muse:&nbsp;<?php totalMuse() ?><br>
Total Dealers:&nbsp;<?php totalDealer() ?><br><br>

Total Raiders:&nbsp;<?php totalRaider() ?><br>
Total Scouts:&nbsp;<?php totalScout() ?><br>
Total Champions:&nbsp;<?php totalChampion() ?><br>
Total Knights:&nbsp;<?php totalKnight() ?><br>
Total Clerics:&nbsp;<?php totalCleric() ?><br>
Total Mages:&nbsp;<?php totalMage() ?><br>
Total Artisans:&nbsp;<?php totalArtisan() ?><br>
Total Bourgeois:&nbsp;<?php totalBourgeois() ?><br>