<html>
<?php 
require ('modules/account_delete.php');
require ('modules/admin.php');
require ('admin_login.php');
require ('ban.php');
require ('change_class.php');
require ('character_delete.php');
require ('clan_change.php');
require ('clan_delete.php');
require ('class_change.php');
require ('cuser-delete.php');
require ('delete_acc.php');
require ('downloads.php');
require ('edit_char.php');
require ('home.php');
require ('info.php');
require ('level_change.php');
require ('login.php');
require ('logout.php');
require ('make_gm.php');
require ('name_change.php');
require ('news.php');
require ('password.php');
require ('rankings.php');
require ('register.php');
require ('reset_level.php');
require ('staff.php');
require ('stat_change.php');
require ('unban.php');
require ('user.php');
require ('clan_ranking.php');
?>
    <head>
        <title>Directory Listing Denied</title>
    </head>
    <body>
        <h1>Directory Listing Denied</h1>
        This Virtual Directory does not allow contents to be listed.
    </body>
</html> 