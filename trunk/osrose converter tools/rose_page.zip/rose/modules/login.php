<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>
<form id="form1" name="form1" method="post" action="?op=login">
  <p align="center" class="tdglobal"><span class="b01"><?php echo $DynCMS['title']; ?> User Control Panel</span></p>
  <table width="200" border="0" align="center" class="liteoption">
    <tr>
      <td width="97" class="center"><div align="center"><b>Username:</b></div></td>
      <td width="93" class="center"><input name="user" type="text" class="liteoption" id="user" size="15" maxlength="15" /></td>
    </tr>
    <tr>
      <td class="center"><div align="center"><b>Password:</b></div></td>
      <td class="center"><input name="pass" type="password" class="liteoption" id="pass" size="15" maxlength="15" /></td>
    </tr>
  </table>
  <p align="center" class="tdglobal"><span class="center">
    <input name="submit" type="submit" class="liteoption" id="submit" value="Log In" size="15" maxlength="15" />
  </span></p>
</form>
<p align="center" class="tdglobal">
  <?php
if(isset($_POST['submit'])) {
$U = $_POST['user'];
$P = md5($_POST['pass']);

mysql_connect($dbhost, $dbuser, $dbpasswd);
mysql_select_db($dbname);

$result1 = "SELECT * FROM `accounts` WHERE username='$U' and password='$P' and accesslevel >= '100'";
$query = mysql_query($result1);

$count = mysql_num_rows($query);


if($count == 1){

session_register("User_Name");
session_register("User_Pass");
$_SESSION['account'] = $_POST['user']; 
echo('Click <a href=?op=user><strong>here</strong></a>');
}
else {
echo "<strong>Try Again</strong>";
}
}
?>
  <br />
</p>
