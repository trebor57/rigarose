<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>
<center><b><?php getConfig('title'); ?> Downloads</b>
<br><br>
<table width="277" border="0" align="center">
  <tr>
    <td width="81">Client:</td>
    <td width="186"><strong>
    <a href="<?php getConfig('client') ?>">Rose Online Client</a>&nbsp;</strong></td>
  </tr>
  <tr>
    <td>Launcher:</td>
    <td><a href="<?php echo getConfig('patch') ?>"><strong><?php getConfig('title'); ?> Launcher</strong></a></td>
  </tr>
</table>
</center>