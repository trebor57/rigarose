<?php
class table 
{
	var $table;
	function __construct($options = NULL) {
		$opt = $this->options($options);

		$this->table .=	'<table '.$opt.' >'."\n";
	}
	function table_header($header = array(),$options = NULL) {
		$opt = $this->options($options);
		$this->table .= "\t".'<tr>'."\n";
		foreach ( $header as $table_name ) {
			if ( $table_name == NULL || strlen($table_name) == 0 ) $table_name = '&nbsp;';
			$this->table .= "\t\t".'<td '.$opt.'><strong>'.$table_name.'</strong></td>'."\n";
		}
		$this->table .= "\t".'</tr>'."\n";	
	}
	function add_values($value = array(),$options = NULL) {
		$opt = $this->options($options);
		$this->table .= "\t".'<tr>'."\n";
		foreach ( $value as $ident ) {
			if ( $ident == NULL || strlen($ident) == 0 ) $ident = '&nbsp;';
			$this->table .= "\t\t".'<td '.$opt.'>'.$ident.'</td>'."\n";
		}		
		$this->table .= "\t".'</tr>'."\n";
	}
	function options($options = NULL ) {
		$opt = NULL;
		if ( !is_null($options) && count($options) > 0 ) {
			foreach ( $options as $option_name => $option_value ) {
				$opt .= $option_name.'="'.$option_value.'" ';
			}
		}
		return $opt;
	}
	function printTable() {
		$this->table .= '</table>'."\n";
		echo $this->table;
	}
	function __destruct() {
		$this->table = NULL;
	}
}
?>