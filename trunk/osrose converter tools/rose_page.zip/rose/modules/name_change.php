<?php 
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

if(!session_is_registered(Admin)) {
}
?>
<form id="form1" name="form1" method="post" action="?op=name_change">
<table width="275" border="0" align="center">
  <tr>
    <td width="98">Current Character Name: </td>
    <td width="167"><label>
      <input type="text" name="textfield1">
    </label></td>
  </tr>
  <tr>
    <td width="98">Desired Character Name: </td>
    <td width="167"><label>
      <input type="text" name="textfield2">
    </label></td>
  </tr>
  <tr>
    <td>Are you sure? </td>
    <td><label>
      <input name="sure" type="checkbox" id="sure" value="checkbox">
    </label></td>
  </tr>
</table>

<p align="center">
  <input name="submit" type="submit" id="submit" />
  <br />
  <br />
<?php
if(isset($_POST['sure'])) {
mysql_query("UPDATE characters SET char_name = '".$_POST['textfield2']."' WHERE char_name = '".$_POST['textfield1']."'");
echo 'Name change successfully.';
} else {
echo 'If you want to change the name, then click the box!';
}
?></p>

</form>
