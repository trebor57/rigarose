<?php
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
?>
<center><small><a href="index.php?op=rankings">-User Ranking-</a></small><br /><h3> Top 50 Clans</h3>
<?PHP
$sql = "SELECT
                c.grade as grade,
                c.name as name
                FROM
                list_clan as c
              ORDER BY
                c.grade
              DESC
              LIMIT 0,50
              ";
$result = @mysql_query($sql) or die(mysql_error());


echo "<table border='0'>";
echo "<tr><th width=1>Clan Grade </th> <th width=40%>Clan Names</th> </tr>";

while($row = mysql_fetch_array( $result )) {
	echo "<tr><td bgcolor=''>"; 
	echo $row['grade'];
	echo "</td><td bgcolor=''>"; 
	echo $row['name'];
	echo "</td></tr>"; 
} 
				echo "</table>";				
	?></center>