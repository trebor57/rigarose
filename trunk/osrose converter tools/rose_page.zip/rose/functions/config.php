<?php
// Ice Dynasty CMS Configuration

// ****************************************************************************************************//
// Database Configuration                                                                              //
// ****************************************************************************************************//

$dbhost 			=	'localhost';		                  // Database Password
$dbuser 			=	'root';			                  // Database Username
$dbpasswd 			=	'root';		                  // Database Password
$dbname 			=	'roseon';			          // Database Name
// ****************************************************************************************************//
// Status Configuration                                                                                //
// ****************************************************************************************************//
$host 			       =	'127.0.0.1';			          // Server IP for status
$log_port 			=	'29000';			          // Server port for status
$char_port 			=	'29100';			          // Server port for status
$world_port 		        =	'29200';			          // Server port for status
$lonline 			=	'<img src=pixels/online.png>';		  // To say when login is online
$conline 			=	'<img src=pixels/on2.png>';	          // To say when char is online
$wonline 			=	'<img src=pixels/on3.png>';		  // To say when world is online
$loffline 			=	'<img src=pixels/offline.png>';		  // To say when login is offline
$coffline 			=	'<img src=pixels/off2.png>';		  // To say when char is offline
$woffline 			=	'<img src=pixels/off3.png>';		  // To say when world is offline
?>
