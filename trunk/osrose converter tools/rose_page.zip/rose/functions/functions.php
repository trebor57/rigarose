<?PHP
/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/



function getConfig($value) {
$dynastyconfig = mysql_query("SELECT * FROM dynastycms") or die(mysql_error());
$dyncms = mysql_fetch_array($dynastyconfig); 
echo $dyncms[$value];
}

function onlineTotal() {
$sql = "SELECT COUNT(id) FROM accounts WHERE online = '1'";
$qry = @mysql_query($sql);
$accounts = mysql_result($qry,0);
echo $accounts;
}

function accTotal() {
$sql = "SELECT COUNT(id) FROM accounts";
$qry = @mysql_query($sql);
$totalacc = mysql_result($qry,0);
echo $totalacc;
}

function charTotal() {
$sql = "SELECT COUNT(id) FROM characters";
$qry = @mysql_query($sql);
$totalc = mysql_result($qry,0);
echo $totalc;
}

function gmTotal() {
$sql = "SELECT COUNT(accesslevel) FROM accounts WHERE accesslevel >= '300'";
$qry = @mysql_query($sql);
$totalg = mysql_result($qry,0);
echo $totalg;
}

function clanTotal() {
$sql = "SELECT COUNT(id) FROM list_clan";
$qry = @mysql_query($sql);
$totalclan = mysql_result($qry,0);
echo $totalclan;

}	
function totalMale() {
$sql = "SELECT COUNT(sex) FROM characters WHERE sex = '0'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalMuse() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '211'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalMage() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '221'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalCleric() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '222'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalVisitor() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '0'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalSoldier() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '111'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalHawker() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '311'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalDealer() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '411'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalKnight() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '121'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalChampion() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '122'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalRaider() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '321'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalScout() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '322'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalArtisan() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '422'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalBourgeois() {
$sql = "SELECT COUNT(id) FROM characters WHERE classid = '421'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function totalFemale() {
$sql = "SELECT COUNT(sex) FROM characters WHERE sex = '1'";
$qry = @mysql_query($sql);
$total = mysql_result($qry,0);
echo $total;
}

function gms() {
$sql = "SELECT GM FROM dynastycms";
$result = @mysql_query($sql) or die(mysql_error());
while($row = mysql_fetch_array( $result )) {
	echo $row['GM']; 
	echo "<br>";
} 
}

function devs() {
$sql = "SELECT Dev FROM dynastycms";
$result = @mysql_query($sql) or die(mysql_error());
while($row = mysql_fetch_array( $result )) {
	echo $row['Dev']; 
	echo "<br>";
} 
}

function admins() {
$sql = "SELECT Admin FROM dynastycms";
$result = @mysql_query($sql) or die(mysql_error());
while($row = mysql_fetch_array( $result )) {
	echo $row['Admin']; 
	echo "<br>";
} 
}




$interval     = time()+120;


error_reporting(0); //without this you will se an error if the server is down.


if($_COOKIE["checked"] != "true")
{
$log = fsockopen($host, $log_port, $errno, $errstr, 1);
$char = fsockopen($host, $char_port, $errno, $errstr, 1);
$world = fsockopen($host, $world_port, $errno, $errstr, 1);

if(!$log){ $log_status = $loffline; setcookie("log_status", "offline", $interval); } else { $log_status = $lonline; }
if(!$char){ $char_status = $coffline; setcookie("char_status", "offline", $interval); } else { $char_status = $conline; }
if(!$world){ $world_status = $woffline; setcookie("world_status", "offline", $interval); } else { $world_status = $wonline; }

setcookie("checked", "true", $interval);
}
else
if($_COOKIE["checked"] == "true")
{
if($_COOKIE["log_status"] == "offline"){ $log_status = $loffline; } else { $log_status = $lonline; }
if($_COOKIE["char_status"] == "offline"){ $char_status = $coffline; } else { $char_status = $conline; }
if($_COOKIE["world_status"] == "offline"){ $world_status = $woffline; } else { $world_status = $wonline; }
} 