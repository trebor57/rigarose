﻿<?php

/* 
DynastyCMS
Copyrigt (C) 2007 dynastycms

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/ 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
require ('functions/config.php');
require ('functions/functions.php');

$rs = mysql_connect($dbhost, $dbuser, $dbpasswd) or die('Could not establish database connection.');
mysql_select_db($dbname,$rs) or die(mysql_error()); 
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php getConfig('title'); ?></title>
<style type="text/css">
<!--
.style3 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; color: #FFFFFF; }
.style4 {color: #000000}
-->
</style>
</head>

<body bgcolor="#000000">
<?php
if(isset($_POST['Login'])) {
$U = $_POST['username'];
$P = md5($_POST['password']);

mysql_connect($dbhost, $dbuser, $dbpasswd);
mysql_select_db($dbname);

$result1 = "SELECT * FROM `accounts` WHERE username='$U' and password='$P' and accesslevel >= '100'";
$query = mysql_query($result1);

$count = mysql_num_rows($query);


if($count == 1){

session_register("Username");
session_register("Password");
$_SESSION['account'] = $_POST['username']; 
echo('Logged in.... Click <a href=?op=user><strong>here</strong></a>');
}
else {
echo "<strong>Try Again</strong>";
}
}
?><table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top"><table width="900" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="left" valign="top"><img src="pixels/header.png" width="900" height="147" /></td>
      </tr>
      <tr>
        <td><table width="899" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFF00">
          <tr>
            <td colspan="2"><img src="pixels/nav.png" width="897" height="44" border="0" usemap="#Map" /></td>
          </tr>
          <tr>
            <td width="329" height="599" align="left" valign="top" bgcolor="#000000"><br />
              <table width="300" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFF00">
              <tr>
                <td height="96" align="left" valign="top" background="pixels/loginform.png"><table width="310" border="0" cellspacing="0" cellpadding="3">
                  <tr>
                    <td align="left" valign="top"><img src="pixels/log.png" width="310" height="44" /></td>
                  </tr>
                  <tr>
                    <td bgcolor="#8AFA07"><form id="form1" name="form1" method="post" action="">
            
            <table width="306" border="0" align="center" cellpadding="3" cellspacing="0" class="liteoption">
    <tr>
      <td width="113" valign="top" bgcolor="#8AFA07" class="center"><div align="center"><b>Username:</b></div></td>
      <td width="193" valign="top" bgcolor="#8AFA07" class="center"><input name="user" type="text" class="liteoption" id="user" size="15" maxlength="15" /></td>
    </tr>
    <tr>
      <td valign="top" bgcolor="#8AFA07" class="center"><div align="center"><b>Password:</b></div></td>
      <td valign="top" bgcolor="#8AFA07" class="center"><input name="pass" type="password" class="liteoption" id="pass" size="15" maxlength="15" />
       <br /></td>
    </tr>
  </table>
             &nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?op=admin_login">Admin?</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <input name="submit" type="submit" class="liteoption" id="submit" value="Log In" size="15" maxlength="15" />
    <?php
if(isset($_POST['submit'])) {
$U = $_POST['user'];
$P = md5($_POST['pass']);

mysql_connect($dbhost, $dbuser, $dbpasswd);
mysql_select_db($dbname);

$result1 = "SELECT * FROM `accounts` WHERE username='$U' and password='$P' and accesslevel >= '100'";
$query = mysql_query($result1);

$count = mysql_num_rows($query);


if($count == 1){

session_register("User_Name");
session_register("User_Pass");
$_SESSION['account'] = $_POST['user']; 
echo('Logged in.... ');
}
else {
echo('Logged in.... Click <a href=?op=user><strong>here</strong></a>');
}
}
?>
                    </form></td>
                  </tr>
                </table>                  </td>
              </tr>
            </table>
              <br /><table width="310" border="0" align="center" cellpadding="3" cellspacing="0">
                <tr>
                  <td><img src="pixels/serverstatus.png" width="310" height="44" /></td>
                </tr>
                <tr>
                  <td background="pixels/loginform.png" bgcolor="#8AFA07"><table width="100%" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td width="55%" bgcolor="#8AFA07"><span class="style3">Login Server:</span></td>
            <td width="45%" bgcolor="#8AFA07"><?php echo "".$log_status; ?></td>
          </tr>
        </table><table width="100%" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td width="55%" bgcolor="#8AFA07"><span class="style3">Character Server:</span></td>
            <td width="45%" bgcolor="#8AFA07"><?php echo "".$char_status; ?></td>
          </tr>
        </table><table width="100%" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td width="55%" bgcolor="#8AFA07"><span class="style3">World Server:</span></td>
            <td width="45%" bgcolor="#8AFA07"><?php echo "".$world_status; ?></td>
          </tr>
        </table>
        <br /><table width="200" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFF00">
          <tr>
            <td align="left" valign="top" bgcolor="#FFFF00"><span class="style3"><span class="style4">Online Count:</span> 
              <?php onlineTotal(); ?></span></td>
          </tr>
        </table>         </td>
                </tr>
              </table>
              <br /><table width="310" border="0" align="center" cellpadding="3" cellspacing="0">
                <tr>
                  <td><img src="pixels/screen.png" width="310" height="44" /></td>
                </tr>
                <tr>
                  <td height="149" align="left" valign="top" bgcolor="#8AFA07">&nbsp;</td>
                </tr>
              </table>
              <p>&nbsp;</p></td>
            <td width="566" align="left" valign="top" bgcolor="#000000"><br /><table width="560" height="365" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td width="556" height="311" align="left" valign="top" bgcolor="#CCCCCC"><?PHP 
if (isset($_GET['write'])) {
	$argv = explode('-',$_GET['write']);
	settype($argv,'array'); 
	$_GET['op'] = @$argv[0];
	$_GET['url'] = @$argv[1];
	$_GET['do'] = @$argv[2];
	$_GET['key'] = @$argv[3];
}
$op = !isset($_GET['op']) ? home : $_GET['op'] ;

   if (is_file("modules/".$op.".php")) {
   		include("modules/".$op.".php");
	
   } else {	
		include ('modules/home.php'); 
   }
?>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2" align="left" valign="top" bgcolor="#8AFA07"><div id="pagefooter_copyright"> 
              <div align="center">
                <p><strong>Rigamrts ©</strong> <span title="10.133.141.121"><strong>20</strong></span><span title="48712680"><strong>09</strong></span><br />
                </p>
                </div>
            </div></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>

<map name="Map" id="Map"><area shape="rect" coords="18,8,82,35" href="index.php?op=home" />
<area shape="rect" coords="112,9,192,36" href="index.php?op=register" />
<area shape="rect" coords="224,10,333,34" href="index.php?op=downloads" />
<area shape="rect" coords="361,10,440,33" href="<?php getConfig('forums'); ?>" /><area shape="rect" coords="467,10,561,34" href="index.php?op=rankings" />
<area shape="rect" coords="592,10,643,33" href="index.php?op=staff" />
</map></body>
</html>
